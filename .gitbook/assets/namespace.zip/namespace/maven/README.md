# Maven配置

注意：`依赖管理`与`common包`需要把`原有的引用去掉`

* 依赖管理

```xml
    <parent>
        <groupId>com</groupId>
        <artifactId>hmmy-cloud</artifactId>
        <version>1.0.0</version>
        <relativePath/>
    </parent>
```


* common包

```xml
    <dependency>
        <groupId>com.hmmy</groupId>
        <artifactId>cloud-common</artifactId>
        <version>1.0.0</version>
    </dependency>
```

* 依赖包

```xml
    <!-- SpringCloud Alibaba Nacos -->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
    </dependency>

    <!-- SpringCloud Alibaba Nacos Config -->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-nacos-config</artifactId>
    </dependency>

    <!-- SpringCloud Alibaba Sentinel -->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-sentinel</artifactId>
    </dependency>

    <!-- SpringBoot Actuator -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>
```

* 依赖冲突解决

建议使用idea插件`Maven Helper`

* 打包

```xml
    <build>
        <finalName>${project.artifactId}</finalName>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <executions>
                    <execution>
                        <goals>
                            <goal>repackage</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
```




